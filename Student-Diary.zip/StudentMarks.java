package project;

public interface StudentMarks {

	//public void viewMarks();
	public void viewInternalmarks();
	public void viewEndsemmarks();
	public void viewContinuousEvaluation();
	
	
}