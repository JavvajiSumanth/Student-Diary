package project;
import java.util.*;
public class FacultyControl {

	
	
ArrayList<Faculty> a = new ArrayList<Faculty>();
Faculty[] faculty = {new Faculty("Counsellor","CSE","amma123"),new Faculty("Teacher","CSE","amrita123"),new Faculty("advisor","CSE","amma123")};
private String s ="Controller";


	Boolean b;
	
	
	
	
 	//public void CheckingInstance(Object o)
	//if()


	
	
}