package project;
public interface Attendance
{

	public void getAttendance(int rollno);
	public void getAttendance(int rollno,String Subject);
	





}