package project;

public interface ClubAttendance {
	public void getClubAttendance(Student obj);


}