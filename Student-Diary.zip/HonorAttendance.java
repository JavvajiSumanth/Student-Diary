package project;

public interface HonorAttendance
{

	public void getHonorAttendance(HonorStudent obj);

}