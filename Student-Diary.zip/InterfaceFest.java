package project;

public interface InterfaceFest {
	
	public Boolean Participated();
	public int NoEventsParticipated();
	public String EventName();
	

}