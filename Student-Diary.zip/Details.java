package project;
public interface Details{
	public String getName();
	public String getAddress();
	public int getRollno();
	public String getParents();
	public String getBloodGroup();
	public String getDOB();
	public String getSemester();
	public String id();
}